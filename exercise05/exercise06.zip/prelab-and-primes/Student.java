class Student{
    
    String firstName, surname;
    
    Student(String firstName, String surname){
        this.firstName = firstName; 
        this.surname = surname;
    }

    String getFirstName(){
        return firstName;
    }

    String getSurname(){
        return surname;
    }
}